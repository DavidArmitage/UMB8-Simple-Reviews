var baseForm_FormId = "";

$(document).ready(function () {
    var UMB8SR_reCaptchaFocus = function () {
        var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = 'https://www.google.com/recaptcha/api.js';
        head.appendChild(script);
    };

    var responseQueryString = UMB8SR_getParameterByName("response");
    if (responseQueryString && responseQueryString.length > 0) {
        UMB8SR_reCaptchaFocus();
    }
    else {
        $(".trigger-reCaptcha").focusin(function () {
            UMB8SR_reCaptchaFocus();
        });
    }

    var $messageSection = $('.message-section');
    if ($messageSection.length) {
        var serverError = $('.message-section').first();
        var serverScrollPos = serverError.offset().top;
        $(window).scrollTop(serverScrollPos - 100);
    }
});

function UMB8SR_triggerFormValidation(formId) {
    baseForm_FormId = formId;
    if ($("#" + formId).valid()) {
        $("#" + formId + "-ajax-loader").show();
        $("#btn" + formId).attr("disabled", true);

        var reCaptchaID = UMB8SR_GetReCaptchaID(baseForm_FormId + "_g-recaptcha");
        grecaptcha.reset(reCaptchaID);
        grecaptcha.execute(reCaptchaID);
    }
    else {
        var errorDiv = $('.field-validation-error').first();
        var scrollPos = errorDiv.offset().top;
        $(window).scrollTop(scrollPos - 100);
    }
}

function UMB8SR_triggerFormSubmitWithValidation(formId) {
    baseForm_FormId = formId;
    if ($("#" + formId).valid()) {
        $("#" + formId + "-ajax-loader").show();
        $("#btn" + formId).attr("disabled", true);
        var $Form = $("#" + baseForm_FormId);
        $Form.submit();
    }
    else {
        var errorDiv = $('.field-validation-error').first();
        var scrollPos = errorDiv.offset().top;
        $(window).scrollTop(scrollPos - 100);
    }
}

function UMB8SR_triggerFormSubmission() {
    var $Form = $("#" + baseForm_FormId);
    $Form.submit();
}

function UMB8SR_getParameterByName(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function UMB8SR_GetReCaptchaID(containerID) {
    var retval = -1;

    $(".g-recaptcha").each(function (index) {
        if (this.id == containerID) {
            retval = index;
            return;
        }
    });

    return retval;
}